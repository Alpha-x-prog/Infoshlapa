<template>
    <footer class="footer">
        <span>© 2025 ИнфоSlapa</span>
        <div class="messenger-icons">
        <a href="https://www.mirea.ru">Связь с разработчиком</a>
        </div>
    </footer>
</template>

<script>

</script>

<style scoped>
    .footer{
        background-color: rgba(112, 124, 130, 1);
        width: 65%;
        min-height: 70px;
        margin: 0 auto;
        padding: 0 60px;
        /*position: absolute;
        bottom: 0px;*/
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: aliceblue;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14pt;
    }
    .footer a{
        text-decoration: none;
        color: rgb(182, 192, 201);
    }
    .footer a:hover{
        color: aliceblue;
    }
</style>